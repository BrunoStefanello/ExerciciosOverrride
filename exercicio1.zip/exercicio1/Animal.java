/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio1;

/**
 *
 * @author Bruno Stefanello
 */
public class Animal {
    
    public void emitirSom(){
        System.out.println("O animal emitiu um som.");
    }
    
    public void mover(){
        System.out.println("o animal se moveu.");
    }
}
