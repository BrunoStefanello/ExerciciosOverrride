/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio1;

/**
 *
 * @author Bruno Stefanello
 */
public class ExercicioOverrride {

    public static void main(String[] args) {
        Animal animal = new Cachorro();
        animal.emitirSom();
        animal.mover();
        
        animal = new Gato();
        animal.emitirSom();
        animal.mover();
        
    }
}
